package com.techelevator;

import java.util.ArrayList;
import java.util.List;

public class BankCustomer {
    private String name;
    private String address;
    private String phoneNumber;
    private List<Accountable> accounts = new ArrayList<>();

    //public static void BankCustomer(String[] args) {
    //List<Accountable> accounts = new ArrayList<>();

    //* getters & setters boi
    public String getName() {
        return name;
    }

    public void setName() {
    }

    public String getAddress() {
        return address;
    }

    public void setAddress() {
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber() {
    }
    //* methods

    public void addAccount(Accountable newAccount) {
          this.accounts.add(newAccount);                         //*adds newAccount to list of accnts
    }

    public Accountable[] getAccounts() {
        return accounts.toArray(new Accountable[accounts.size()]);

    }
    public boolean isVip(){
        int netWorth = 0;
        for (Accountable account : accounts){
            netWorth += account.getBalance();
        } int Vip_Threshold = 25000;
        return netWorth > Vip_Threshold;
    }
}
