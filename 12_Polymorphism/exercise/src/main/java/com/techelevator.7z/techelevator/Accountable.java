package com.techelevator;

public interface Accountable {
        public abstract int getBalance();
    }
